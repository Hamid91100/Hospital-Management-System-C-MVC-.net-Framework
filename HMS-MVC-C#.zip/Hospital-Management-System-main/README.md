# Hospital-Management-System
Hospital Management System using C#/.Net Core created where functionality like user validation, Doctor login, Patient details, Diagnosis summary and print of summary can be done
#login details
DocName: Aman
Password:Aman123
 First login then go to the section you want and add, delete or update details according to required and you can print the diagnosis summary if requird.
