﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySqlConnector;

namespace Hospital_management_system
{
    public partial class DiagnosisForm : Form
    {
        public DiagnosisForm()
        {
            InitializeComponent();
        }
        MySqlConnection Con = new MySqlConnection("datasource=localhost; username=root; password=; database=hospitaldb;");
        void populateData()
        {
            string sql = "select * from PatientTbl";
            MySqlCommand cmd = new MySqlCommand(sql, Con);
            MySqlDataReader rdr;
            try
            {
                Con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("PatientId", typeof(int));
                rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                PatientIdCb.ValueMember = "PatId";
                PatientIdCb.DataSource = dt;
                Con.Close();
            }
            catch
            {

            }
        }
        string patname;
        void fetchpatientname()
        {
            Con.Open();
            string mysql = "select * from PatientTbl where PatId=" + PatientIdCb.SelectedValue.ToString() + "";
            MySqlCommand cmd = new MySqlCommand(mysql, Con);
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                patname = dr["Patname"].ToString();
                PatientTb.Text = patname;
            }
            Con.Close();
        }
        void populateDataintoSummary()
        {
            Con.Open();
            string query = "select * from DiagnosisTbl";
            MySqlDataAdapter da = new MySqlDataAdapter(query, Con);
            MySqlCommandBuilder builder = new MySqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            DiagnosisGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void HomePageReturn(object sender, EventArgs e)
        {
            HomeP h = new HomeP();
            h.Show();
            this.Hide();
        }

        private void insertPatientDiagnosis(object sender, EventArgs e)
        {
            if (DiagId.Text == "" || PatientIdCb.Text == "" || MedicineTb.Text == "" || DiagnosisTb.Text == "" || PatientTb.Text == "" || SymptomsTb.Text == "")
                MessageBox.Show("No empty fill accepted");
            else
            {
                Con.Open();
                string query = "insert into DiagnosisTbl values(" + DiagId.Text + "," + PatientIdCb.SelectedValue.ToString() + ",'" + PatientTb.Text + "','" + SymptomsTb.Text + "','" + DiagnosisTb.Text + "','" + MedicineTb.Text + "')";
                MySqlCommand cmd = new MySqlCommand(query, Con);
                cmd.ExecuteNonQuery();     
                MessageBox.Show("Diagnosis successfully Added"); ;
                Con.Close();
                populateDataintoSummary();
            }
        }

        private void DiagnosisForm_Load(object sender, EventArgs e)
        {
            Con.Open();
            string sql = "Select DiagId from diagnosistbl";
            MySqlCommand cmd = new MySqlCommand(sql, Con);
            int Id = (int) cmd.ExecuteScalar();
            DiagId.Text = (Id+1).ToString();
            Con.Close();

            populateData();
            populateDataintoSummary();
        }

        private void PatientIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchpatientname();
        }

        private void deleteDiagnosis(object sender, EventArgs e)
        {
            if (DiagId.Text == "")
                MessageBox.Show("Enter the Diagnosis Id");
            else
            {
                Con.Open();
                string query = "delete from DiagnosisTbl where DiagId=" + DiagId.Text + "";
                MySqlCommand cmd = new MySqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Diagnosis Successfully deleted");
                Con.Close();
                populateDataintoSummary();

            }

        }

        private void updateDiagnosis(object sender, EventArgs e)
        {
            if (DiagId.Text == "" || PatientIdCb.Text == "" || MedicineTb.Text == "" || DiagnosisTb.Text == "" || PatientTb.Text == "" || SymptomsTb.Text == "")
                MessageBox.Show("No empty fill accepted");
            else
            {
                Con.Open();
                string query = "update DiagnosisTbl set PatientIdCb ='" + PatientIdCb.SelectedValue.ToString() + "',PatName ='" + PatientTb.Text + "', Symptoms ='" + SymptomsTb.Text + "' , Diagnosis ='" + DiagnosisTb.Text + "',Medicines ='" + MedicineTb.Text + "' where DiagId=" + DiagId.Text + "";
                MySqlCommand cmd = new MySqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Diagnosis Successfully updated");
                Con.Close();
                populateDataintoSummary();

            }
        }

        private void DiagnosisGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DiagId.Text = DiagnosisGV.SelectedRows[0].Cells[0].Value.ToString();
            PatientIdCb.SelectedValue = DiagnosisGV.SelectedRows[0].Cells[1].Value.ToString();
            PatientTb.Text = DiagnosisGV.SelectedRows[0].Cells[2].Value.ToString();
            SymptomsTb.Text = DiagnosisGV.SelectedRows[0].Cells[3].Value.ToString();
            DiagnosisTb.Text = DiagnosisGV.SelectedRows[0].Cells[4].Value.ToString();
            MedicineTb.Text = DiagnosisGV.SelectedRows[0].Cells[5].Value.ToString();
            Patientlbl.Text = DiagnosisGV.SelectedRows[0].Cells[2].Value.ToString();
            Diagnosislbl.Text = DiagnosisGV.SelectedRows[0].Cells[4].Value.ToString();
            Symptomslbl.Text = DiagnosisGV.SelectedRows[0].Cells[3].Value.ToString();
            Medicineslbl.Text = DiagnosisGV.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void PrintDocument(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(label4.Text, new Font("Century Gothic", 25, FontStyle.Bold), Brushes.Black, new Point(230));
            e.Graphics.DrawString(Patientlbl.Text + "\n" + Diagnosislbl.Text + "\n" + Symptomslbl.Text + "\n" + Medicineslbl.Text, new Font("Century Gothic", 12, FontStyle.Bold), Brushes.Black, new Point(130, 150));
            e.Graphics.DrawString(label10.Text + "\n", new Font("Century Gothic", 25, FontStyle.Bold), Brushes.Black, new Point(230, 500));

        }

        private void PrintDoc(object sender, EventArgs e)
        {
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }
        }

        private void ExitApp(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}

