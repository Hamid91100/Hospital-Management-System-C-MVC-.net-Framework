﻿namespace Hospital_management_system
{
    partial class SelectionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SelectionForm));
            this.SystemLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.docPic = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ModuleLogin = new System.Windows.Forms.Label();
            this.patPic = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.docPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.patPic)).BeginInit();
            this.SuspendLayout();
            // 
            // SystemLabel
            // 
            this.SystemLabel.AutoSize = true;
            this.SystemLabel.BackColor = System.Drawing.Color.Transparent;
            this.SystemLabel.Enabled = false;
            this.SystemLabel.Font = new System.Drawing.Font("Showcard Gothic", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SystemLabel.ForeColor = System.Drawing.SystemColors.WindowText;
            this.SystemLabel.Location = new System.Drawing.Point(179, 28);
            this.SystemLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.SystemLabel.Name = "SystemLabel";
            this.SystemLabel.Size = new System.Drawing.Size(622, 46);
            this.SystemLabel.TabIndex = 0;
            this.SystemLabel.Text = "HOSPITAL MANAGEMENT SYSTEM";
            this.SystemLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Purple;
            this.panel1.Controls.Add(this.SystemLabel);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1024, 110);
            this.panel1.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Symbol", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Image = global::Hospital_management_system.Properties.Resources.shutdown;
            this.label5.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label5.Location = new System.Drawing.Point(1014, 0);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 30);
            this.label5.TabIndex = 11;
            this.label5.Text = "X";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.docPic);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(12, 301);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(924, 232);
            this.panel2.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Enabled = false;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label2.Location = new System.Drawing.Point(575, 125);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 46);
            this.label2.TabIndex = 19;
            this.label2.Text = "Patient";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // docPic
            // 
            this.docPic.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.docPic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.docPic.Image = ((System.Drawing.Image)(resources.GetObject("docPic.Image")));
            this.docPic.Location = new System.Drawing.Point(307, -3);
            this.docPic.Margin = new System.Windows.Forms.Padding(2);
            this.docPic.Name = "docPic";
            this.docPic.Size = new System.Drawing.Size(116, 113);
            this.docPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.docPic.TabIndex = 1;
            this.docPic.TabStop = false;
            this.docPic.Click += new System.EventHandler(this.docPic_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Enabled = false;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label1.Location = new System.Drawing.Point(217, 125);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 46);
            this.label1.TabIndex = 18;
            this.label1.Text = "ADMIN/DOC";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // ModuleLogin
            // 
            this.ModuleLogin.AutoSize = true;
            this.ModuleLogin.BackColor = System.Drawing.Color.Transparent;
            this.ModuleLogin.Enabled = false;
            this.ModuleLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ModuleLogin.Font = new System.Drawing.Font("Showcard Gothic", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ModuleLogin.ForeColor = System.Drawing.SystemColors.WindowText;
            this.ModuleLogin.Location = new System.Drawing.Point(351, 195);
            this.ModuleLogin.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ModuleLogin.Name = "ModuleLogin";
            this.ModuleLogin.Size = new System.Drawing.Size(288, 46);
            this.ModuleLogin.TabIndex = 17;
            this.ModuleLogin.Text = "Enter App AS:";
            this.ModuleLogin.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // patPic
            // 
            this.patPic.BackColor = System.Drawing.Color.Coral;
            this.patPic.Image = ((System.Drawing.Image)(resources.GetObject("patPic.Image")));
            this.patPic.Location = new System.Drawing.Point(595, 301);
            this.patPic.Margin = new System.Windows.Forms.Padding(2);
            this.patPic.Name = "patPic";
            this.patPic.Size = new System.Drawing.Size(120, 113);
            this.patPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.patPic.TabIndex = 3;
            this.patPic.TabStop = false;
            this.patPic.Click += new System.EventHandler(this.patPic_Click);
            // 
            // SelectionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 601);
            this.Controls.Add(this.patPic);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.ModuleLogin);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SelectionForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SelectionForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.docPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.patPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label SystemLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox patPic;
        private System.Windows.Forms.PictureBox docPic;
        private System.Windows.Forms.Label ModuleLogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}