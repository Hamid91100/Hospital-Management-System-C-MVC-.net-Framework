﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_management_system
{
    public partial class SelectionForm : Form
    {
        public SelectionForm()
        {
            InitializeComponent();
        }

        private void docPic_Click(object sender, EventArgs e)
        {
            Login p = new Login();
            p.Show();
        }

        private void patPic_Click(object sender, EventArgs e)
        {
            PatientView ps = new PatientView();
           // PatientCollection ps = new PatientCollection();
            ps.Show();
        }
    }
}
