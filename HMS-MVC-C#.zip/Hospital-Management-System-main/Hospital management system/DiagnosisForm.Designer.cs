﻿namespace Hospital_management_system
{
    partial class DiagnosisForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DiagnosisForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.DiagId = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.PatientIdCb = new System.Windows.Forms.ComboBox();
            this.PatientTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.SymptomsTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.DiagnosisTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.MedicineTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.addBtn = new System.Windows.Forms.Button();
            this.DelBtn = new System.Windows.Forms.Button();
            this.updBtn = new System.Windows.Forms.Button();
            this.Home = new System.Windows.Forms.Button();
            this.DiagnosisList = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.Medicineslbl = new System.Windows.Forms.Label();
            this.Diagnosislbl = new System.Windows.Forms.Label();
            this.Symptomslbl = new System.Windows.Forms.Label();
            this.Patientlbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.DiagnosisGV = new Guna.UI.WinForms.GunaDataGridView();
            this.PrintBtn = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DiagnosisGV)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Purple;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1032, 109);
            this.panel1.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 18.2F);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(996, 7);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 35);
            this.label5.TabIndex = 10;
            this.label5.Text = "X";
            this.label5.Click += new System.EventHandler(this.ExitApp);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Location = new System.Drawing.Point(451, 61);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(183, 41);
            this.label2.TabIndex = 2;
            this.label2.Text = "DIAGNOSIS";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(304, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(511, 41);
            this.label1.TabIndex = 1;
            this.label1.Text = "HOSPITAL MANAGEMENT SYSTEM";
            // 
            // DiagId
            // 
            this.DiagId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DiagId.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.DiagId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.DiagId.HintForeColor = System.Drawing.Color.Empty;
            this.DiagId.HintText = "";
            this.DiagId.isPassword = false;
            this.DiagId.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.DiagId.LineIdleColor = System.Drawing.Color.Gray;
            this.DiagId.LineMouseHoverColor = System.Drawing.Color.BlueViolet;
            this.DiagId.LineThickness = 3;
            this.DiagId.Location = new System.Drawing.Point(33, 172);
            this.DiagId.Margin = new System.Windows.Forms.Padding(4);
            this.DiagId.Name = "DiagId";
            this.DiagId.Size = new System.Drawing.Size(127, 36);
            this.DiagId.TabIndex = 3;
            this.DiagId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // PatientIdCb
            // 
            this.PatientIdCb.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatientIdCb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PatientIdCb.FormattingEnabled = true;
            this.PatientIdCb.Location = new System.Drawing.Point(33, 228);
            this.PatientIdCb.Margin = new System.Windows.Forms.Padding(2);
            this.PatientIdCb.Name = "PatientIdCb";
            this.PatientIdCb.Size = new System.Drawing.Size(128, 27);
            this.PatientIdCb.TabIndex = 8;
            this.PatientIdCb.Text = "PatientId";
            this.PatientIdCb.SelectionChangeCommitted += new System.EventHandler(this.PatientIdCb_SelectionChangeCommitted);
            // 
            // PatientTb
            // 
            this.PatientTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PatientTb.Enabled = false;
            this.PatientTb.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.PatientTb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PatientTb.HintForeColor = System.Drawing.Color.Empty;
            this.PatientTb.HintText = "";
            this.PatientTb.isPassword = false;
            this.PatientTb.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.PatientTb.LineIdleColor = System.Drawing.Color.Gray;
            this.PatientTb.LineMouseHoverColor = System.Drawing.Color.BlueViolet;
            this.PatientTb.LineThickness = 3;
            this.PatientTb.Location = new System.Drawing.Point(33, 265);
            this.PatientTb.Margin = new System.Windows.Forms.Padding(4);
            this.PatientTb.Name = "PatientTb";
            this.PatientTb.Size = new System.Drawing.Size(127, 36);
            this.PatientTb.TabIndex = 9;
            this.PatientTb.Text = "PatientName";
            this.PatientTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // SymptomsTb
            // 
            this.SymptomsTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SymptomsTb.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.SymptomsTb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SymptomsTb.HintForeColor = System.Drawing.Color.Empty;
            this.SymptomsTb.HintText = "";
            this.SymptomsTb.isPassword = false;
            this.SymptomsTb.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.SymptomsTb.LineIdleColor = System.Drawing.Color.Gray;
            this.SymptomsTb.LineMouseHoverColor = System.Drawing.Color.BlueViolet;
            this.SymptomsTb.LineThickness = 3;
            this.SymptomsTb.Location = new System.Drawing.Point(247, 173);
            this.SymptomsTb.Margin = new System.Windows.Forms.Padding(4);
            this.SymptomsTb.Name = "SymptomsTb";
            this.SymptomsTb.Size = new System.Drawing.Size(127, 36);
            this.SymptomsTb.TabIndex = 10;
            this.SymptomsTb.Text = "Symptoms";
            this.SymptomsTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // DiagnosisTb
            // 
            this.DiagnosisTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DiagnosisTb.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.DiagnosisTb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.DiagnosisTb.HintForeColor = System.Drawing.Color.Empty;
            this.DiagnosisTb.HintText = "";
            this.DiagnosisTb.isPassword = false;
            this.DiagnosisTb.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.DiagnosisTb.LineIdleColor = System.Drawing.Color.Gray;
            this.DiagnosisTb.LineMouseHoverColor = System.Drawing.Color.BlueViolet;
            this.DiagnosisTb.LineThickness = 3;
            this.DiagnosisTb.Location = new System.Drawing.Point(247, 215);
            this.DiagnosisTb.Margin = new System.Windows.Forms.Padding(4);
            this.DiagnosisTb.Name = "DiagnosisTb";
            this.DiagnosisTb.Size = new System.Drawing.Size(127, 36);
            this.DiagnosisTb.TabIndex = 11;
            this.DiagnosisTb.Text = "Diagnosis";
            this.DiagnosisTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // MedicineTb
            // 
            this.MedicineTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MedicineTb.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MedicineTb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.MedicineTb.HintForeColor = System.Drawing.Color.Empty;
            this.MedicineTb.HintText = "";
            this.MedicineTb.isPassword = false;
            this.MedicineTb.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.MedicineTb.LineIdleColor = System.Drawing.Color.Gray;
            this.MedicineTb.LineMouseHoverColor = System.Drawing.Color.BlueViolet;
            this.MedicineTb.LineThickness = 3;
            this.MedicineTb.Location = new System.Drawing.Point(247, 265);
            this.MedicineTb.Margin = new System.Windows.Forms.Padding(4);
            this.MedicineTb.Name = "MedicineTb";
            this.MedicineTb.Size = new System.Drawing.Size(127, 36);
            this.MedicineTb.TabIndex = 12;
            this.MedicineTb.Text = "Medicines";
            this.MedicineTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // addBtn
            // 
            this.addBtn.BackColor = System.Drawing.Color.Purple;
            this.addBtn.FlatAppearance.BorderSize = 0;
            this.addBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.addBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.addBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.addBtn.Location = new System.Drawing.Point(33, 336);
            this.addBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(127, 41);
            this.addBtn.TabIndex = 15;
            this.addBtn.Text = "ADD";
            this.addBtn.UseVisualStyleBackColor = false;
            this.addBtn.Click += new System.EventHandler(this.insertPatientDiagnosis);
            // 
            // DelBtn
            // 
            this.DelBtn.BackColor = System.Drawing.Color.Purple;
            this.DelBtn.FlatAppearance.BorderSize = 0;
            this.DelBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.DelBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.DelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DelBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DelBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.DelBtn.Location = new System.Drawing.Point(247, 336);
            this.DelBtn.Margin = new System.Windows.Forms.Padding(2);
            this.DelBtn.Name = "DelBtn";
            this.DelBtn.Size = new System.Drawing.Size(127, 41);
            this.DelBtn.TabIndex = 16;
            this.DelBtn.Text = "DELETE";
            this.DelBtn.UseVisualStyleBackColor = false;
            this.DelBtn.Click += new System.EventHandler(this.deleteDiagnosis);
            // 
            // updBtn
            // 
            this.updBtn.BackColor = System.Drawing.Color.Purple;
            this.updBtn.FlatAppearance.BorderSize = 0;
            this.updBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.updBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.updBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.updBtn.Location = new System.Drawing.Point(33, 404);
            this.updBtn.Margin = new System.Windows.Forms.Padding(2);
            this.updBtn.Name = "updBtn";
            this.updBtn.Size = new System.Drawing.Size(127, 41);
            this.updBtn.TabIndex = 17;
            this.updBtn.Text = "UPDATE";
            this.updBtn.UseVisualStyleBackColor = false;
            this.updBtn.Click += new System.EventHandler(this.updateDiagnosis);
            // 
            // Home
            // 
            this.Home.BackColor = System.Drawing.Color.Purple;
            this.Home.FlatAppearance.BorderSize = 0;
            this.Home.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Home.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Home.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Home.Location = new System.Drawing.Point(247, 404);
            this.Home.Margin = new System.Windows.Forms.Padding(2);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(127, 41);
            this.Home.TabIndex = 18;
            this.Home.Text = "HOME";
            this.Home.UseVisualStyleBackColor = false;
            this.Home.Click += new System.EventHandler(this.HomePageReturn);
            // 
            // DiagnosisList
            // 
            this.DiagnosisList.AutoSize = true;
            this.DiagnosisList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DiagnosisList.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiagnosisList.ForeColor = System.Drawing.Color.Purple;
            this.DiagnosisList.Location = new System.Drawing.Point(393, 483);
            this.DiagnosisList.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DiagnosisList.Name = "DiagnosisList";
            this.DiagnosisList.Size = new System.Drawing.Size(241, 32);
            this.DiagnosisList.TabIndex = 20;
            this.DiagnosisList.Text = "DIAGNOSIS LIST      ";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.Medicineslbl);
            this.panel2.Controls.Add(this.Diagnosislbl);
            this.panel2.Controls.Add(this.Symptomslbl);
            this.panel2.Controls.Add(this.Patientlbl);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(406, 129);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(573, 314);
            this.panel2.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 18.2F);
            this.label10.ForeColor = System.Drawing.Color.Purple;
            this.label10.Location = new System.Drawing.Point(96, 263);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(397, 35);
            this.label10.TabIndex = 9;
            this.label10.Text = "HOSPITAL MANAGEMENT SYSTEM";
            // Medicineslbl
            // 
            this.Medicineslbl.AutoSize = true;
            this.Medicineslbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Medicineslbl.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.Medicineslbl.ForeColor = System.Drawing.Color.Purple;
            this.Medicineslbl.Location = new System.Drawing.Point(437, 172);
            this.Medicineslbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Medicineslbl.Name = "Medicineslbl";
            this.Medicineslbl.Size = new System.Drawing.Size(123, 32);
            this.Medicineslbl.TabIndex = 7;
            this.Medicineslbl.Text = "Medicines";
            // 
            // Diagnosislbl
            // 
            this.Diagnosislbl.AutoSize = true;
            this.Diagnosislbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Diagnosislbl.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.Diagnosislbl.ForeColor = System.Drawing.Color.Purple;
            this.Diagnosislbl.Location = new System.Drawing.Point(437, 99);
            this.Diagnosislbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Diagnosislbl.Name = "Diagnosislbl";
            this.Diagnosislbl.Size = new System.Drawing.Size(117, 32);
            this.Diagnosislbl.TabIndex = 6;
            this.Diagnosislbl.Text = "Diagnosis";
            // 
            // Symptomslbl
            // 
            this.Symptomslbl.AutoSize = true;
            this.Symptomslbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Symptomslbl.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.Symptomslbl.ForeColor = System.Drawing.Color.Purple;
            this.Symptomslbl.Location = new System.Drawing.Point(23, 172);
            this.Symptomslbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Symptomslbl.Name = "Symptomslbl";
            this.Symptomslbl.Size = new System.Drawing.Size(126, 32);
            this.Symptomslbl.TabIndex = 5;
            this.Symptomslbl.Text = "Symptoms";
            // 
            // Patientlbl
            // 
            this.Patientlbl.AutoSize = true;
            this.Patientlbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Patientlbl.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Patientlbl.ForeColor = System.Drawing.Color.Purple;
            this.Patientlbl.Location = new System.Drawing.Point(23, 96);
            this.Patientlbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Patientlbl.Name = "Patientlbl";
            this.Patientlbl.Size = new System.Drawing.Size(151, 32);
            this.Patientlbl.TabIndex = 4;
            this.Patientlbl.Text = "PatientName";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Purple;
            this.label4.Location = new System.Drawing.Point(172, 10);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(276, 32);
            this.label4.TabIndex = 3;
            this.label4.Text = "DIAGNOSIS SUMMARY";
            // 
            // DiagnosisGV
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.DiagnosisGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DiagnosisGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DiagnosisGV.BackgroundColor = System.Drawing.Color.White;
            this.DiagnosisGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DiagnosisGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DiagnosisGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.BlueViolet;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DiagnosisGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DiagnosisGV.ColumnHeadersHeight = 30;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DiagnosisGV.DefaultCellStyle = dataGridViewCellStyle3;
            this.DiagnosisGV.EnableHeadersVisualStyles = false;
            this.DiagnosisGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DiagnosisGV.Location = new System.Drawing.Point(60, 517);
            this.DiagnosisGV.Margin = new System.Windows.Forms.Padding(2);
            this.DiagnosisGV.Name = "DiagnosisGV";
            this.DiagnosisGV.RowHeadersVisible = false;
            this.DiagnosisGV.RowHeadersWidth = 40;
            this.DiagnosisGV.RowTemplate.Height = 30;
            this.DiagnosisGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DiagnosisGV.Size = new System.Drawing.Size(920, 171);
            this.DiagnosisGV.TabIndex = 22;
            this.DiagnosisGV.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.DiagnosisGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.DiagnosisGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DiagnosisGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DiagnosisGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DiagnosisGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DiagnosisGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DiagnosisGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DiagnosisGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.BlueViolet;
            this.DiagnosisGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DiagnosisGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiagnosisGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DiagnosisGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DiagnosisGV.ThemeStyle.HeaderStyle.Height = 30;
            this.DiagnosisGV.ThemeStyle.ReadOnly = false;
            this.DiagnosisGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.DiagnosisGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DiagnosisGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.DiagnosisGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DiagnosisGV.ThemeStyle.RowsStyle.Height = 30;
            this.DiagnosisGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DiagnosisGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DiagnosisGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DiagnosisGV_CellContentClick);
            // 
            // PrintBtn
            // 
            this.PrintBtn.BackColor = System.Drawing.Color.Purple;
            this.PrintBtn.FlatAppearance.BorderSize = 0;
            this.PrintBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.PrintBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.PrintBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PrintBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.PrintBtn.Location = new System.Drawing.Point(903, 457);
            this.PrintBtn.Margin = new System.Windows.Forms.Padding(2);
            this.PrintBtn.Name = "PrintBtn";
            this.PrintBtn.Size = new System.Drawing.Size(77, 30);
            this.PrintBtn.TabIndex = 23;
            this.PrintBtn.Text = "PRINT";
            this.PrintBtn.UseVisualStyleBackColor = false;
            this.PrintBtn.Click += new System.EventHandler(this.PrintDoc);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintDocument);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Purple;
            this.label6.Location = new System.Drawing.Point(37, 129);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(196, 32);
            this.label6.TabIndex = 24;
            this.label6.Text = "ENTER DETAILS:";
            // 
            // DiagnosisForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1032, 640);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.PrintBtn);
            this.Controls.Add(this.DiagnosisGV);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.DiagnosisList);
            this.Controls.Add(this.Home);
            this.Controls.Add(this.updBtn);
            this.Controls.Add(this.DelBtn);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.MedicineTb);
            this.Controls.Add(this.DiagnosisTb);
            this.Controls.Add(this.SymptomsTb);
            this.Controls.Add(this.PatientTb);
            this.Controls.Add(this.PatientIdCb);
            this.Controls.Add(this.DiagId);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "DiagnosisForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DiagnosisForm";
            this.Load += new System.EventHandler(this.DiagnosisForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DiagnosisGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox DiagId;
        private System.Windows.Forms.ComboBox PatientIdCb;
        private Bunifu.Framework.UI.BunifuMaterialTextbox PatientTb;
        private Bunifu.Framework.UI.BunifuMaterialTextbox SymptomsTb;
        private Bunifu.Framework.UI.BunifuMaterialTextbox DiagnosisTb;
        private Bunifu.Framework.UI.BunifuMaterialTextbox MedicineTb;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button DelBtn;
        private System.Windows.Forms.Button updBtn;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Label DiagnosisList;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label Symptomslbl;
        private System.Windows.Forms.Label Patientlbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label Medicineslbl;
        private System.Windows.Forms.Label Diagnosislbl;
        private Guna.UI.WinForms.GunaDataGridView DiagnosisGV;
        private System.Windows.Forms.Button PrintBtn;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}