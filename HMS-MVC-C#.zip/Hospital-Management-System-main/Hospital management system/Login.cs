﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySqlConnector;

namespace Hospital_management_system
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        MySqlConnection Con = new MySqlConnection("datasource=localhost; username=root; password=; database=hospitaldb;");
        private void bunifuMetroTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
          

        }

        private void bunifuMetroTextbox1_OnValueChanged_1(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
            Con.Open();

            if (DocNameTb.Text == "" || PassTb.Text == "")
            {
                HomeP H = new HomeP();
                H.Show();
                this.Hide();
                MessageBox.Show("Enter a Username and Password");
            }
            else
            {
                string mysql = "select Count(*) from DoctorTbl where DocName = '" + DocNameTb.Text + "' and DocPass = '" + PassTb.Text + "'";
                MySqlCommand cmd = new MySqlCommand(mysql, Con);
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);

                if (dt.Rows[0][0].ToString() == "1")
                {
                    HomeP p = new HomeP();
                    p.Show();
                }
                else
                {
                    MessageBox.Show("Wrong username or Password");

                }
                Con.Close();


            }
        }
    }

}