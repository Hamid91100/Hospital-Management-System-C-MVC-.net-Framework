﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySqlConnector;


namespace Hospital_management_system
{
    public partial class DoctorCollection : Form
    {
        MySqlConnection Con = new MySqlConnection("datasource=localhost; username=root; password=; database=hospitaldb;");

        public DoctorCollection()
        {
            InitializeComponent();
        }
        void populateData()
        {
            Con.Open();
            string query = "select * from DoctorTbl";
            MySqlDataAdapter da = new MySqlDataAdapter(query, Con);
            MySqlCommandBuilder builder = new MySqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            DoctorGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void addDoctor(object sender, EventArgs e)
        {
            DoctorAdd a = new DoctorAdd();
            a.Show();
            this.Hide();
           }

        private void homePage(object sender, EventArgs e)
        {
            this.Hide();

            HomeP h = new HomeP();
            h.Show();
            this.Hide();
        }

        private void Doctorform_Load(object sender, EventArgs e)
        {
            populateData();
        }

        private void deleteDoctor(object sender, EventArgs e)
        {
            this.Hide();

            DoctorDelete y = new DoctorDelete();
            y.Show();
            this.Hide();
/*
            if (DocId.Text == "")
                MessageBox.Show("Enter the Doctor Id");
            else
            {
                Con.Open();
                string query = "delete from DoctorTbl where DocId=" + DocId.Text + "";
                MySqlCommand cmd = new MySqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Doctor Successfully deleted");
                Con.Close();
                populateData();

            }
  */
            }

       /* private void DoctorGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DocId.Text = DoctorGV.SelectedRows[0].Cells[0].Value.ToString();
            DocName.Text = DoctorGV.SelectedRows[0].Cells[1].Value.ToString();
            DocExp.Text = DoctorGV.SelectedRows[0].Cells[2].Value.ToString();
            DocPass.Text = DoctorGV.SelectedRows[0].Cells[3].Value.ToString();
        }*/

        private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void updateDoctor(object sender, EventArgs e)
        {
            this.Hide();

            DoctorUpdate s = new DoctorUpdate();
            s.Show();
            this.Hide();

          /*Con.Open();
            string query = "update DoctorTbl set DocName ='" + DocName.Text + "',DocExp ='" + DocExp.Text + "', DocPass ='" + DocPass.Text + "' where DocId=" + DocId.Text + "";
            MySqlCommand cmd = new MySqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Doctor Successfully updated");
            Con.Close();
            populateData();
          */
        }

        private void exitApp(object sender, EventArgs e)
        {
            Application.Exit();
        }


    }
}
