﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace Hospital_management_system
{
    public partial class PatientCollection : Form
    {

        public PatientCollection()
        {
            InitializeComponent();
        }
        MySqlConnection Con = new MySqlConnection("datasource=localhost; username=root; password=; database=hospitaldb;");

        void populateData()
        {
            Con.Open();
            string query = "select * from PatientTbl";
            MySqlDataAdapter da = new MySqlDataAdapter(query, Con);
            MySqlCommandBuilder builder = new MySqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            PatientGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void homePage(object sender, EventArgs e)
        {
            HomeP h = new HomeP();
            h.Show();
            this.Hide();
        }

        private void addPatient(object sender, EventArgs e)
        {
            this.Hide();

            PatientAddForm f = new PatientAddForm();
            f.Show();

            /*
            if (PatId.Text == "" || PatName.Text == "" || PatAdd.Text == "" || PatCon.Text == "" || PatAge.Text == "" || MajorDis.Text == "" || GenderCb.SelectedItem == null || BloodCb.SelectedItem == null)
                MessageBox.Show("No empty fill accepted");
            else
            {
                Con.Open();
                string query = "insert into PatientTbl values(" + PatId.Text + ",'" + PatName.Text + "','" + PatAdd.Text + "','" + PatCon.Text + "','" + PatAge.Text + "','" + GenderCb.SelectedItem.ToString() + "','" + BloodCb.SelectedItem.ToString() + "','" + MajorDis.Text + "')";
                MySqlCommand cmd = new MySqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient successfully Added"); ;
                Con.Close();
                populateData();
            }*/
        }

        private void PopulatePatientData(object sender, EventArgs e)
        {
            populateData();
        }
        private void PatId_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void DoctorGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void MajorDis_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void PatAdd_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void deletePatient(object sender, EventArgs e)
        {
            this.Hide();
            PatientDeleteForm f = new PatientDeleteForm();
            f.Show();
        }

        private void updatePatient(object sender, EventArgs e)
        {
            this.Hide();

            PatientUpdateForm Up = new PatientUpdateForm();
            Up.Show();
            this.Hide();

           }

      /*  private void PatientGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            PatId.Text = PatientGV.SelectedRows[0].Cells[0].Value.ToString();
            PatName.Text = PatientGV.SelectedRows[0].Cells[1].Value.ToString();
            PatAdd.Text = PatientGV.SelectedRows[0].Cells[2].Value.ToString();
            PatCon.Text = PatientGV.SelectedRows[0].Cells[3].Value.ToString();
            PatAge.Text = PatientGV.SelectedRows[0].Cells[4].Value.ToString();
            MajorDis.Text = PatientGV.SelectedRows[0].Cells[7].Value.ToString();
        }
      */
        private void ExitApp(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PatId_OnValueChanged_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
