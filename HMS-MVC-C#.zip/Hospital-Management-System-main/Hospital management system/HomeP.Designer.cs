﻿namespace Hospital_management_system
{
    partial class HomeP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomeP));
            this.SystemLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.DiagBtn = new System.Windows.Forms.Button();
            this.PatBtn = new System.Windows.Forms.Button();
            this.DocBtn = new System.Windows.Forms.Button();
            this.DiagPic = new System.Windows.Forms.PictureBox();
            this.patPic = new System.Windows.Forms.PictureBox();
            this.docPic = new System.Windows.Forms.PictureBox();
            this.ModuleLogin = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DiagPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.patPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.docPic)).BeginInit();
            this.SuspendLayout();
            // 
            // SystemLabel
            // 
            this.SystemLabel.AutoSize = true;
            this.SystemLabel.BackColor = System.Drawing.Color.Transparent;
            this.SystemLabel.Enabled = false;
            this.SystemLabel.Font = new System.Drawing.Font("Showcard Gothic", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SystemLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.SystemLabel.Location = new System.Drawing.Point(163, 24);
            this.SystemLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.SystemLabel.Name = "SystemLabel";
            this.SystemLabel.Size = new System.Drawing.Size(622, 46);
            this.SystemLabel.TabIndex = 0;
            this.SystemLabel.Text = "HOSPITAL MANAGEMENT SYSTEM";
            this.SystemLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Purple;
            this.panel1.Controls.Add(this.SystemLabel);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1045, 110);
            this.panel1.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Symbol", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Image = global::Hospital_management_system.Properties.Resources.shutdown;
            this.label5.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label5.Location = new System.Drawing.Point(1014, 0);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 30);
            this.label5.TabIndex = 11;
            this.label5.Text = "X";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.DiagBtn);
            this.panel2.Controls.Add(this.PatBtn);
            this.panel2.Controls.Add(this.DocBtn);
            this.panel2.Controls.Add(this.DiagPic);
            this.panel2.Controls.Add(this.patPic);
            this.panel2.Controls.Add(this.docPic);
            this.panel2.Location = new System.Drawing.Point(108, 297);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(760, 229);
            this.panel2.TabIndex = 13;
            // 
            // DiagBtn
            // 
            this.DiagBtn.BackColor = System.Drawing.Color.Purple;
            this.DiagBtn.FlatAppearance.BorderSize = 0;
            this.DiagBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.DiagBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.DiagBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DiagBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiagBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.DiagBtn.Location = new System.Drawing.Point(548, 2);
            this.DiagBtn.Margin = new System.Windows.Forms.Padding(2);
            this.DiagBtn.Name = "DiagBtn";
            this.DiagBtn.Size = new System.Drawing.Size(127, 63);
            this.DiagBtn.TabIndex = 16;
            this.DiagBtn.Text = "DIAGNOSIS MENU";
            this.DiagBtn.UseVisualStyleBackColor = false;
            this.DiagBtn.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // PatBtn
            // 
            this.PatBtn.BackColor = System.Drawing.Color.Purple;
            this.PatBtn.FlatAppearance.BorderSize = 0;
            this.PatBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.PatBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.PatBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PatBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.PatBtn.Location = new System.Drawing.Point(307, 2);
            this.PatBtn.Margin = new System.Windows.Forms.Padding(2);
            this.PatBtn.Name = "PatBtn";
            this.PatBtn.Size = new System.Drawing.Size(120, 63);
            this.PatBtn.TabIndex = 16;
            this.PatBtn.Text = "PATIENT MENU";
            this.PatBtn.UseVisualStyleBackColor = false;
            this.PatBtn.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // DocBtn
            // 
            this.DocBtn.BackColor = System.Drawing.Color.Purple;
            this.DocBtn.FlatAppearance.BorderSize = 0;
            this.DocBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.DocBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.DocBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DocBtn.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.DocBtn.Location = new System.Drawing.Point(63, 2);
            this.DocBtn.Margin = new System.Windows.Forms.Padding(2);
            this.DocBtn.Name = "DocBtn";
            this.DocBtn.Size = new System.Drawing.Size(116, 63);
            this.DocBtn.TabIndex = 16;
            this.DocBtn.Text = "DOCTOR MENU";
            this.DocBtn.UseVisualStyleBackColor = false;
            this.DocBtn.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // DiagPic
            // 
            this.DiagPic.BackColor = System.Drawing.Color.Azure;
            this.DiagPic.Image = ((System.Drawing.Image)(resources.GetObject("DiagPic.Image")));
            this.DiagPic.Location = new System.Drawing.Point(556, 78);
            this.DiagPic.Margin = new System.Windows.Forms.Padding(2);
            this.DiagPic.Name = "DiagPic";
            this.DiagPic.Size = new System.Drawing.Size(119, 116);
            this.DiagPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.DiagPic.TabIndex = 5;
            this.DiagPic.TabStop = false;
            this.DiagPic.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // patPic
            // 
            this.patPic.BackColor = System.Drawing.Color.Coral;
            this.patPic.Image = ((System.Drawing.Image)(resources.GetObject("patPic.Image")));
            this.patPic.Location = new System.Drawing.Point(307, 81);
            this.patPic.Margin = new System.Windows.Forms.Padding(2);
            this.patPic.Name = "patPic";
            this.patPic.Size = new System.Drawing.Size(120, 113);
            this.patPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.patPic.TabIndex = 3;
            this.patPic.TabStop = false;
            this.patPic.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // docPic
            // 
            this.docPic.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.docPic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.docPic.Image = ((System.Drawing.Image)(resources.GetObject("docPic.Image")));
            this.docPic.Location = new System.Drawing.Point(63, 81);
            this.docPic.Margin = new System.Windows.Forms.Padding(2);
            this.docPic.Name = "docPic";
            this.docPic.Size = new System.Drawing.Size(116, 113);
            this.docPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.docPic.TabIndex = 1;
            this.docPic.TabStop = false;
            this.docPic.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // ModuleLogin
            // 
            this.ModuleLogin.AutoSize = true;
            this.ModuleLogin.BackColor = System.Drawing.Color.Transparent;
            this.ModuleLogin.Enabled = false;
            this.ModuleLogin.Font = new System.Drawing.Font("Showcard Gothic", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ModuleLogin.ForeColor = System.Drawing.SystemColors.WindowText;
            this.ModuleLogin.Location = new System.Drawing.Point(163, 169);
            this.ModuleLogin.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ModuleLogin.Name = "ModuleLogin";
            this.ModuleLogin.Size = new System.Drawing.Size(638, 46);
            this.ModuleLogin.TabIndex = 14;
            this.ModuleLogin.Text = "LOGIN TO YOUR DESIRED MODULE";
            this.ModuleLogin.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // HomeP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1045, 580);
            this.Controls.Add(this.ModuleLogin);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "HomeP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DiagPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.patPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.docPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SystemLabel;
        private System.Windows.Forms.PictureBox docPic;
        private System.Windows.Forms.PictureBox patPic;
        private System.Windows.Forms.PictureBox DiagPic;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button DiagBtn;
        private System.Windows.Forms.Button PatBtn;
        private System.Windows.Forms.Button DocBtn;
        private System.Windows.Forms.Label ModuleLogin;
    }
}