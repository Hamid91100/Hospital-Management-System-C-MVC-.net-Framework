﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_management_system
{
    public partial class PatientUpdateForm : Form
    {
        public PatientUpdateForm()
        {
            InitializeComponent();
        }
        MySqlConnection Con = new MySqlConnection("datasource=localhost; username=root; password=; database=hospitaldb;");

        void populate()
        {
            Con.Open();
            string query = "select * from PatientTbl";
            MySqlDataAdapter da = new MySqlDataAdapter(query, Con);
            MySqlCommandBuilder builder = new MySqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
          //  PatientGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void PatName_OnValueChanged(object sender, EventArgs e)
        {
 }

        private void button3_Click(object sender, EventArgs e)
        {

            if (PatId.Text == "" ||  PatAdd.Text == "" || PatCon.Text == "" || PatAge.Text == "" || MajorDis.Text == "" ||  BloodCb.SelectedItem == null)
                MessageBox.Show("No empty fill accepted");
            else
            {
                Con.Open();
                string query = "update PatientTbl set PatAdd ='" + PatAdd.Text + "', PatCon ='" + PatCon.Text + "' , PatAge ='" + PatAge.Text + "', BloodCb ='" + BloodCb.SelectedItem.ToString() + "' , MajorDis ='" + MajorDis.Text + "' where PatId=" + PatId.Text + "";
                MySqlCommand cmd = new MySqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Successfully updated");
                Con.Close();
                
                populate();

                PatientCollection pc = new PatientCollection();
                pc.Show();

            }
        }

        private void PatientGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void PatCon_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void PatId_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void PatAge_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            HomeP h = new HomeP();
            h.Show();
            this.Hide();
        }
    }
}
