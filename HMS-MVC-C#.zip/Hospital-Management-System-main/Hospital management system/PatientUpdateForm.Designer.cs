﻿namespace Hospital_management_system
{
    partial class PatientUpdateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.MajorDis = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.BloodCb = new System.Windows.Forms.ComboBox();
            this.PatAge = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.PatAdd = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.PatId = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.PatCon = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Purple;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button4.Location = new System.Drawing.Point(112, 601);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(86, 41);
            this.button4.TabIndex = 29;
            this.button4.Text = "HOME";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Purple;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button3.Location = new System.Drawing.Point(420, 437);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(106, 41);
            this.button3.TabIndex = 28;
            this.button3.Text = "UPDATE";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // MajorDis
            // 
            this.MajorDis.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MajorDis.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MajorDis.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.MajorDis.HintForeColor = System.Drawing.Color.Empty;
            this.MajorDis.HintText = "";
            this.MajorDis.isPassword = false;
            this.MajorDis.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.MajorDis.LineIdleColor = System.Drawing.Color.Gray;
            this.MajorDis.LineMouseHoverColor = System.Drawing.Color.BlueViolet;
            this.MajorDis.LineThickness = 3;
            this.MajorDis.Location = new System.Drawing.Point(439, 369);
            this.MajorDis.Margin = new System.Windows.Forms.Padding(4);
            this.MajorDis.Name = "MajorDis";
            this.MajorDis.Size = new System.Drawing.Size(127, 34);
            this.MajorDis.TabIndex = 25;
            this.MajorDis.Text = "MajorDisbility";
            this.MajorDis.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // BloodCb
            // 
            this.BloodCb.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BloodCb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BloodCb.FormattingEnabled = true;
            this.BloodCb.Items.AddRange(new object[] {
            "A+",
            "B+",
            "O+",
            "AB+",
            "A-",
            "B-",
            "O-",
            "AB-"});
            this.BloodCb.Location = new System.Drawing.Point(439, 330);
            this.BloodCb.Margin = new System.Windows.Forms.Padding(2);
            this.BloodCb.Name = "BloodCb";
            this.BloodCb.Size = new System.Drawing.Size(128, 27);
            this.BloodCb.TabIndex = 24;
            this.BloodCb.Text = "BloodGroup";
            // 
            // PatAge
            // 
            this.PatAge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PatAge.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.PatAge.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PatAge.HintForeColor = System.Drawing.Color.Empty;
            this.PatAge.HintText = "";
            this.PatAge.isPassword = false;
            this.PatAge.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.PatAge.LineIdleColor = System.Drawing.Color.Gray;
            this.PatAge.LineMouseHoverColor = System.Drawing.Color.BlueViolet;
            this.PatAge.LineThickness = 3;
            this.PatAge.Location = new System.Drawing.Point(439, 276);
            this.PatAge.Margin = new System.Windows.Forms.Padding(4);
            this.PatAge.Name = "PatAge";
            this.PatAge.Size = new System.Drawing.Size(127, 34);
            this.PatAge.TabIndex = 22;
            this.PatAge.Text = "PatientAge";
            this.PatAge.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.PatAge.OnValueChanged += new System.EventHandler(this.PatAge_OnValueChanged);
            // 
            // PatAdd
            // 
            this.PatAdd.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PatAdd.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.PatAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PatAdd.HintForeColor = System.Drawing.Color.Empty;
            this.PatAdd.HintText = "";
            this.PatAdd.isPassword = false;
            this.PatAdd.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.PatAdd.LineIdleColor = System.Drawing.Color.Gray;
            this.PatAdd.LineMouseHoverColor = System.Drawing.Color.BlueViolet;
            this.PatAdd.LineThickness = 3;
            this.PatAdd.Location = new System.Drawing.Point(439, 170);
            this.PatAdd.Margin = new System.Windows.Forms.Padding(4);
            this.PatAdd.Name = "PatAdd";
            this.PatAdd.Size = new System.Drawing.Size(127, 34);
            this.PatAdd.TabIndex = 20;
            this.PatAdd.Text = "PatientAddress";
            this.PatAdd.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.PatAdd.OnValueChanged += new System.EventHandler(this.PatName_OnValueChanged);
            // 
            // PatId
            // 
            this.PatId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PatId.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.PatId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PatId.HintForeColor = System.Drawing.Color.Empty;
            this.PatId.HintText = "";
            this.PatId.isPassword = false;
            this.PatId.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.PatId.LineIdleColor = System.Drawing.Color.Gray;
            this.PatId.LineMouseHoverColor = System.Drawing.Color.BlueViolet;
            this.PatId.LineThickness = 3;
            this.PatId.Location = new System.Drawing.Point(439, 115);
            this.PatId.Margin = new System.Windows.Forms.Padding(4);
            this.PatId.Name = "PatId";
            this.PatId.Size = new System.Drawing.Size(127, 36);
            this.PatId.TabIndex = 18;
            this.PatId.Text = "PatientId";
            this.PatId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.PatId.OnValueChanged += new System.EventHandler(this.PatId_OnValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 18.2F);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(1071, 7);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 35);
            this.label5.TabIndex = 17;
            this.label5.Text = "X";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Location = new System.Drawing.Point(493, 61);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 41);
            this.label2.TabIndex = 2;
            this.label2.Text = "PATIENT";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(304, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(511, 41);
            this.label1.TabIndex = 1;
            this.label1.Text = "HOSPITAL MANAGEMENT SYSTEM";
            // 
            // PatCon
            // 
            this.PatCon.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PatCon.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.PatCon.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PatCon.HintForeColor = System.Drawing.Color.Empty;
            this.PatCon.HintText = "";
            this.PatCon.isPassword = false;
            this.PatCon.LineFocusedColor = System.Drawing.Color.BlueViolet;
            this.PatCon.LineIdleColor = System.Drawing.Color.Gray;
            this.PatCon.LineMouseHoverColor = System.Drawing.Color.BlueViolet;
            this.PatCon.LineThickness = 3;
            this.PatCon.Location = new System.Drawing.Point(439, 221);
            this.PatCon.Margin = new System.Windows.Forms.Padding(4);
            this.PatCon.Name = "PatCon";
            this.PatCon.Size = new System.Drawing.Size(127, 34);
            this.PatCon.TabIndex = 21;
            this.PatCon.Text = "PatientContactno.";
            this.PatCon.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.PatCon.OnValueChanged += new System.EventHandler(this.PatCon_OnValueChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Purple;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1024, 109);
            this.panel1.TabIndex = 17;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Purple;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button1.Location = new System.Drawing.Point(530, 437);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 41);
            this.button1.TabIndex = 42;
            this.button1.Text = "HOME";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PatientUpdateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 601);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.MajorDis);
            this.Controls.Add(this.BloodCb);
            this.Controls.Add(this.PatAge);
            this.Controls.Add(this.PatAdd);
            this.Controls.Add(this.PatId);
            this.Controls.Add(this.PatCon);
            this.Controls.Add(this.panel1);
            this.Name = "PatientUpdateForm";
            this.Text = "FORM";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private Bunifu.Framework.UI.BunifuMaterialTextbox MajorDis;
        private System.Windows.Forms.ComboBox BloodCb;
        private Bunifu.Framework.UI.BunifuMaterialTextbox PatAge;
        private Bunifu.Framework.UI.BunifuMaterialTextbox PatAdd;
        private Bunifu.Framework.UI.BunifuMaterialTextbox PatId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox PatCon;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
    }
}