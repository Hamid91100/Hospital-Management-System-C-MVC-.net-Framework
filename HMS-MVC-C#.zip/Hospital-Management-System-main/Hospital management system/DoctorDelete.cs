﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_management_system
{
    public partial class DoctorDelete : Form
    {
        public DoctorDelete()
        {
            InitializeComponent();
        }

        MySqlConnection Con = new MySqlConnection("datasource=localhost; username=root; password=; database=hospitaldb;");

        void populate()
        {
            Con.Open();
            string query = "select * from DoctorTbl";
            MySqlDataAdapter da = new MySqlDataAdapter(query, Con);
            MySqlCommandBuilder builder = new MySqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            //  DoctorGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" Do you really want to Delete? Press OK to Confirm!");

            if (DocId.Text == "")
                MessageBox.Show("Enter the Doctor Id");
            else
            {
                Con.Open();
                string query = "delete from DoctorTbl where DocId=" + DocId.Text + "";
                MySqlCommand cmd = new MySqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Doctor Successfully deleted");
                Con.Close();
                populate();

                DoctorCollection s = new DoctorCollection();
                s.Show();
                this.Hide();

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            HomeP h = new HomeP();
            h.Show();
            this.Hide();
        }
    }
}
